/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const { ApolloError } = __webpack_require__(232);
const dbconfig = {
    host: "nmegx0z0tj4ho1.cxjpzndq5h93.us-west-1.rds.amazonaws.com",
    database: process.env.DB_NAME,
    user: process.env.USERNAME,
    password: process.env.PASSWORD
};
const client = __webpack_require__(202)({
    config: dbconfig
});
const resetdb = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Resetting DB config: ", dbconfig);
    yield client.query(`
  CREATE TABLE IF NOT EXISTS shirts
  (
      id MEDIUMINT UNSIGNED not null AUTO_INCREMENT, 
      created TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
      design varchar(100) not null,
      small INT not null,
      medium INT not null,
      large INT not null,
      PRIMARY KEY (id)
  );  
  `);
    console.log("Clearing Table....");
    yield client.query('DELETE FROM shirts');
    console.log("Adding inital shirts");
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design1", 10, 5, 1]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design2", 3, 2, 5]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design3", 1, 3, 2]);
    yield client.end();
    return "Success";
});
const getAllShirts = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Gettting all Shirts");
    let shirts = [];
    const shirtResults = yield client.query(` select * from shirts`);
    yield client.end();
    for (const shirt of shirtResults) {
        const { id, design, small, medium, large } = shirt;
        console.log(`Shirt ID:${id} - ${design} : small QTY: ${small} | medium QTY: ${medium} | large QTY: ${large} `);
        shirts.push({ id, design, small, medium, large });
    }
    return shirts;
});
const purchaseShirt = (id, size, qty) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`Purchasing Shirt:  id: ${id},size: ${size}, purchase qty:${qty}`);
    const qtyCheckResults = yield client.query(`SELECT * from shirts WHERE id = ${id}; `);
    console.log("QTY Check REsults: ", qtyCheckResults);
    if (qtyCheckResults[0]) {
        const currentQty = qtyCheckResults[0][size];
        console.log("Current QTY: ", currentQty);
        if (currentQty < qty) {
            throw new ApolloError('Requested QTY exceed QTY Available');
        }
    }
    yield client.query(`UPDATE shirts SET ${size} = ${size} - ${qty} WHERE id = ${id} AND ${size}-${qty}>= 0; `);
    const shirtUpdateResult = yield client.query(`SELECT * from shirts WHERE id = ${id}; `);
    console.log("shirtUpdateResult: ", shirtUpdateResult[0]);
    yield client.end();
    return shirtUpdateResult[0];
});
exports.resolvers = {
    Query: {
        hello: () => 'Hello world!',
        getAll: () => __awaiter(void 0, void 0, void 0, function* () { return yield getAllShirts(); })
    },
    Mutation: {
        reset: () => __awaiter(void 0, void 0, void 0, function* () { return yield resetdb(); }),
        purchase: (_, params) => __awaiter(void 0, void 0, void 0, function* () {
            const { id, size, qty } = params;
            return yield purchaseShirt(id, size, qty);
        })
    }
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
exports.typeDefs = apollo_server_lambda_1.gql `
type Shirt {
  id:Int
  design:String
  small:Int
  medium:Int
  large:Int
}

type User {
	UUID: String
	Name: String
	Posts: [Post]
}

type Post {
	UUID: String
	Text: String
}

input UserInput {
	Name: String
	Posts: [PostInput]
}

input PostInput{
	Text: String
}



type Mutation {
	reset:String
  addshirt:String
  purchase(id:Int!,size:String!,qty:Int!):Shirt
}

type Query {
  hello: String
	mysql_getUser(uuid: String!): User
  getAll:[Shirt]
}

schema {
	query: Query
	mutation: Mutation
}
`;


/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("apollo-server");;

/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    typeDefs: type_defs_1.typeDefs,
    resolvers: resolvers_1.resolvers
});
exports.graphqlHandler = apolloServer.createHandler({
    cors: {
        origin: '*',
        credentials: true,
    },
});

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiL2V4dGVybmFsIFwiYXBvbGxvLXNlcnZlclwiIiwid2VicGFjazovL3NlcnZlcmxlc3MtZGIvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL3NlcnZlcmxlc3MtZGIvZXh0ZXJuYWwgXCJzZXJ2ZXJsZXNzLW15c3FsXCIiLCJ3ZWJwYWNrOi8vc2VydmVybGVzcy1kYi93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL2Fwb2xsby1zZXJ2ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5jb25zdCB7QXBvbGxvRXJyb3J9ID0gcmVxdWlyZSgnYXBvbGxvLXNlcnZlcicpO1xuXG5jb25zdCBkYmNvbmZpZyA9IHtcbiAgaG9zdDogXCJubWVneDB6MHRqNGhvMS5jeGpwem5kcTVoOTMudXMtd2VzdC0xLnJkcy5hbWF6b25hd3MuY29tXCIsLy9wcm9jZXNzLmVudi5NWVNRTF9IT1NULFxuICBkYXRhYmFzZTogcHJvY2Vzcy5lbnYuREJfTkFNRSxcbiAgdXNlcjogcHJvY2Vzcy5lbnYuVVNFUk5BTUUsXG4gIHBhc3N3b3JkOiBwcm9jZXNzLmVudi5QQVNTV09SRFxufVxuXG5cbmNvbnN0IGNsaWVudCA9IHJlcXVpcmUoJ3NlcnZlcmxlc3MtbXlzcWwnKSh7XG4gIGNvbmZpZzpkYmNvbmZpZ1xufSlcblxuXG5jb25zdCByZXNldGRiID0gYXN5bmMgKCkgPT4ge1xuY29uc29sZS5sb2coXCJSZXNldHRpbmcgREIgY29uZmlnOiBcIixkYmNvbmZpZylcblxuICBhd2FpdCBjbGllbnQucXVlcnkoYFxuICBDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBzaGlydHNcbiAgKFxuICAgICAgaWQgTUVESVVNSU5UIFVOU0lHTkVEIG5vdCBudWxsIEFVVE9fSU5DUkVNRU5ULCBcbiAgICAgIGNyZWF0ZWQgVElNRVNUQU1QIERFRkFVTFQgQ1VSUkVOVF9USU1FU1RBTVAsIFxuICAgICAgZGVzaWduIHZhcmNoYXIoMTAwKSBub3QgbnVsbCxcbiAgICAgIHNtYWxsIElOVCBub3QgbnVsbCxcbiAgICAgIG1lZGl1bSBJTlQgbm90IG51bGwsXG4gICAgICBsYXJnZSBJTlQgbm90IG51bGwsXG4gICAgICBQUklNQVJZIEtFWSAoaWQpXG4gICk7ICBcbiAgYClcbiAgY29uc29sZS5sb2coXCJDbGVhcmluZyBUYWJsZS4uLi5cIilcbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCdERUxFVEUgRlJPTSBzaGlydHMnKVxuICBjb25zb2xlLmxvZyhcIkFkZGluZyBpbml0YWwgc2hpcnRzXCIpXG5cbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCAnSU5TRVJUIElOVE8gc2hpcnRzIChkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlKSBWQUxVRVMoPyw/LD8sPyknLCBbXCJkZXNpZ24xXCIsMTAsNSwxXSk7XG4gIGF3YWl0IGNsaWVudC5xdWVyeSggJ0lOU0VSVCBJTlRPIHNoaXJ0cyAoZGVzaWduLHNtYWxsLG1lZGl1bSxsYXJnZSkgVkFMVUVTKD8sPyw/LD8pJywgW1wiZGVzaWduMlwiLDMsMiw1XSk7XG4gIGF3YWl0IGNsaWVudC5xdWVyeSggJ0lOU0VSVCBJTlRPIHNoaXJ0cyAoZGVzaWduLHNtYWxsLG1lZGl1bSxsYXJnZSkgVkFMVUVTKD8sPyw/LD8pJywgW1wiZGVzaWduM1wiLDEsMywyXSk7XG4gIFxuICAvLyBSdW4gY2xlYW4gdXAgZnVuY3Rpb25cbiAgYXdhaXQgY2xpZW50LmVuZCgpXG4gIHJldHVybiBcIlN1Y2Nlc3NcIlxufVxuXG5cblxuXG5jb25zdCBnZXRBbGxTaGlydHMgPSBhc3luYyAoKSA9PiB7XG4gIGNvbnNvbGUubG9nKFwiR2V0dHRpbmcgYWxsIFNoaXJ0c1wiKVxuICBsZXQgc2hpcnRzID0gW11cbiAgY29uc3Qgc2hpcnRSZXN1bHRzID0gYXdhaXQgY2xpZW50LnF1ZXJ5KGAgc2VsZWN0ICogZnJvbSBzaGlydHNgKVxuICBhd2FpdCBjbGllbnQuZW5kKClcbiAgZm9yKGNvbnN0IHNoaXJ0IG9mIHNoaXJ0UmVzdWx0cyl7XG4gICAgY29uc3Qge2lkLGRlc2lnbixzbWFsbCxtZWRpdW0sbGFyZ2V9ID0gc2hpcnRcbiAgICBjb25zb2xlLmxvZyhgU2hpcnQgSUQ6JHtpZH0gLSAke2Rlc2lnbn0gOiBzbWFsbCBRVFk6ICR7c21hbGx9IHwgbWVkaXVtIFFUWTogJHttZWRpdW19IHwgbGFyZ2UgUVRZOiAke2xhcmdlfSBgKVxuICAgIHNoaXJ0cy5wdXNoKHtpZCxkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlfSlcbiAgfVxuICByZXR1cm4gc2hpcnRzXG59XG5cbmNvbnN0IHB1cmNoYXNlU2hpcnQgPSBhc3luYyAoaWQ6TnVtYmVyLHNpemU6c3RyaW5nLHF0eTpOdW1iZXIpID0+IHtcbiAgY29uc29sZS5sb2coYFB1cmNoYXNpbmcgU2hpcnQ6ICBpZDogJHtpZH0sc2l6ZTogJHtzaXplfSwgcHVyY2hhc2UgcXR5OiR7cXR5fWApXG4gIFxuICBjb25zdCBxdHlDaGVja1Jlc3VsdHMgPSBhd2FpdCBjbGllbnQucXVlcnkoYFNFTEVDVCAqIGZyb20gc2hpcnRzIFdIRVJFIGlkID0gJHtpZH07IGApICBcbiBcbiAgIGNvbnNvbGUubG9nKFwiUVRZIENoZWNrIFJFc3VsdHM6IFwiLHF0eUNoZWNrUmVzdWx0cylcblxuXG4gICBpZihxdHlDaGVja1Jlc3VsdHNbMF0pe1xuICAgICBjb25zdCBjdXJyZW50UXR5ID0gcXR5Q2hlY2tSZXN1bHRzWzBdW3NpemVdXG4gICAgY29uc29sZS5sb2coXCJDdXJyZW50IFFUWTogXCIsY3VycmVudFF0eSlcbiAgICBpZihjdXJyZW50UXR5PHF0eSl7XG4gICAgICAvL0B0cy1pZ25vcmVcbiAgICAgdGhyb3cgbmV3IEFwb2xsb0Vycm9yKCdSZXF1ZXN0ZWQgUVRZIGV4Y2VlZCBRVFkgQXZhaWxhYmxlJyk7XG4gICAgfSBcbiAgIH0gIFxuICAgYXdhaXQgY2xpZW50LnF1ZXJ5KGBVUERBVEUgc2hpcnRzIFNFVCAke3NpemV9ID0gJHtzaXplfSAtICR7cXR5fSBXSEVSRSBpZCA9ICR7aWR9IEFORCAke3NpemV9LSR7cXR5fT49IDA7IGApXG4gIFxuICAgY29uc3Qgc2hpcnRVcGRhdGVSZXN1bHQgPSBhd2FpdCBjbGllbnQucXVlcnkoYFNFTEVDVCAqIGZyb20gc2hpcnRzIFdIRVJFIGlkID0gJHtpZH07IGApICBcbiAgY29uc29sZS5sb2coXCJzaGlydFVwZGF0ZVJlc3VsdDogXCIsc2hpcnRVcGRhdGVSZXN1bHRbMF0pXG4gIGF3YWl0IGNsaWVudC5lbmQoKVxuICByZXR1cm4gc2hpcnRVcGRhdGVSZXN1bHRbMF1cbn1cblxuXG5cbmV4cG9ydCBjb25zdCByZXNvbHZlcnMgPSB7XG5cblxuICBRdWVyeToge1xuICAgIFxuICAgIGhlbGxvOiAoKSA9PiAnSGVsbG8gd29ybGQhJyxcbiAgICBnZXRBbGw6IGFzeW5jICgpID0+IHsgcmV0dXJuIGF3YWl0IGdldEFsbFNoaXJ0cygpIH1cbiAgfSxcbiAgTXV0YXRpb246IHtcbiAgICByZXNldDogIGFzeW5jICgpID0+IHsgcmV0dXJuIGF3YWl0IHJlc2V0ZGIoKX0sICAgXG4gICAgcHVyY2hhc2U6IGFzeW5jIChfOmFueSxwYXJhbXM6YW55KT0+e1xuICAgICAgY29uc3Qge2lkLHNpemUscXR5fSA9IHBhcmFtcztcbiAgICAgIHJldHVybiBhd2FpdCBwdXJjaGFzZVNoaXJ0KGlkLHNpemUscXR5KVxuICAgIH0gICBcblxuICB9XG59O1xuIiwiaW1wb3J0IHsgZ3FsIH0gZnJvbSAnYXBvbGxvLXNlcnZlci1sYW1iZGEnO1xuXG5leHBvcnQgY29uc3QgdHlwZURlZnMgPSBncWxgXG50eXBlIFNoaXJ0IHtcbiAgaWQ6SW50XG4gIGRlc2lnbjpTdHJpbmdcbiAgc21hbGw6SW50XG4gIG1lZGl1bTpJbnRcbiAgbGFyZ2U6SW50XG59XG5cbnR5cGUgVXNlciB7XG5cdFVVSUQ6IFN0cmluZ1xuXHROYW1lOiBTdHJpbmdcblx0UG9zdHM6IFtQb3N0XVxufVxuXG50eXBlIFBvc3Qge1xuXHRVVUlEOiBTdHJpbmdcblx0VGV4dDogU3RyaW5nXG59XG5cbmlucHV0IFVzZXJJbnB1dCB7XG5cdE5hbWU6IFN0cmluZ1xuXHRQb3N0czogW1Bvc3RJbnB1dF1cbn1cblxuaW5wdXQgUG9zdElucHV0e1xuXHRUZXh0OiBTdHJpbmdcbn1cblxuXG5cbnR5cGUgTXV0YXRpb24ge1xuXHRyZXNldDpTdHJpbmdcbiAgYWRkc2hpcnQ6U3RyaW5nXG4gIHB1cmNoYXNlKGlkOkludCEsc2l6ZTpTdHJpbmchLHF0eTpJbnQhKTpTaGlydFxufVxuXG50eXBlIFF1ZXJ5IHtcbiAgaGVsbG86IFN0cmluZ1xuXHRteXNxbF9nZXRVc2VyKHV1aWQ6IFN0cmluZyEpOiBVc2VyXG4gIGdldEFsbDpbU2hpcnRdXG59XG5cbnNjaGVtYSB7XG5cdHF1ZXJ5OiBRdWVyeVxuXHRtdXRhdGlvbjogTXV0YXRpb25cbn1cbmA7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic2VydmVybGVzcy1teXNxbFwiKTs7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0aWYoX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSkge1xuXHRcdHJldHVybiBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCJpbXBvcnQgeyBBcG9sbG9TZXJ2ZXIgfSBmcm9tICdhcG9sbG8tc2VydmVyLWxhbWJkYSc7XG5pbXBvcnQgeyBDb250ZXh0LCBBUElHYXRld2F5RXZlbnQsIEFQSUdhdGV3YXlQcm94eVJlc3VsdFYyIH0gZnJvbSBcImF3cy1sYW1iZGFcIjtcbmltcG9ydCB7IHJlc29sdmVycyB9IGZyb20gJy4vcmVzb2x2ZXJzJztcbmltcG9ydCB7IHR5cGVEZWZzIH0gZnJvbSAnLi90eXBlLWRlZnMnO1xuXG4vL2NvbnN0IGFwb2xsb1NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoeyByZXNvbHZlcnMsIHR5cGVEZWZzIH0pO1xuXG5jb25zdCBhcG9sbG9TZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHtcblxuXHR0eXBlRGVmcyxcblx0cmVzb2x2ZXJzIH0pO1xuXG5cbmV4cG9ydCBjb25zdCBncmFwaHFsSGFuZGxlciA9IGFwb2xsb1NlcnZlci5jcmVhdGVIYW5kbGVyKHtcbiAgICBjb3JzOiB7XG4gICAgICBvcmlnaW46ICcqJyxcbiAgICAgIGNyZWRlbnRpYWxzOiB0cnVlLFxuICAgIH0sXG4gIH0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFFQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFHQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0E7Ozs7Ozs7O0FDeEdBO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBK0NBO0FBQ0E7QUFDQTtBOzs7OztBQ25EQTtBQUNBO0E7Ozs7O0FDREE7QUFDQTtBOzs7OztBQ0RBO0FBQ0E7QTs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3RCQTtBQUVBO0FBQ0E7QUFJQTtBQUVBO0FBQ0E7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QSIsInNvdXJjZVJvb3QiOiIifQ==