/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const dbconfig = {
    host: "nmegx0z0tj4ho1.cxjpzndq5h93.us-west-1.rds.amazonaws.com",
    database: process.env.DB_NAME,
    user: process.env.USERNAME,
    password: process.env.PASSWORD
};
const client = __webpack_require__(202)({
    config: dbconfig
});
const resetdb = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Resetting DB config: ", dbconfig);
    yield client.query(`
  CREATE TABLE IF NOT EXISTS shirts
  (
      id MEDIUMINT UNSIGNED not null AUTO_INCREMENT, 
      created TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
      design varchar(100) not null,
      small INT not null,
      medium INT not null,
      large INT not null,
      PRIMARY KEY (id)
  );  
  `);
    console.log("Clearing Table....");
    yield client.query('DELETE FROM shirts');
    console.log("Adding inital shirts");
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design1", 10, 5, 1]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design2", 3, 2, 5]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design3", 1, 3, 2]);
    yield client.end();
    return "Success";
});
const getAllShirts = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Gettting all Shirts");
    let shirts = [];
    const shirtResults = yield client.query(` select * from shirts`);
    for (const shirt of shirtResults) {
        const { id, design, small, medium, large } = shirt;
        console.log(`Shirt ID:${id} - ${design} : small QTY: ${small} | medium QTY: ${medium} | large QTY: ${large} `);
        shirts.push({ id, design, small, medium, large });
    }
    return shirts;
});
const purchaseShirt = (id, size, qty) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`Purchasing Shirt:  id: ${id},size: ${size}, purchase qty:${qty}`);
    yield client.query(`UPDATE shirts SET ${size} = ${size} - ${qty} WHERE id = ${id} AND ${size}-${qty}>= 0; `);
    const shirtUpdateResult = yield client.query(`SELECT * from shirts WHERE id = ${id}; `);
    console.log("shirtUpdateResult: ", shirtUpdateResult[0]);
    return shirtUpdateResult[0];
});
exports.resolvers = {
    Query: {
        hello: () => 'Hello world!',
        getAll: () => __awaiter(void 0, void 0, void 0, function* () { return yield getAllShirts(); })
    },
    Mutation: {
        reset: () => __awaiter(void 0, void 0, void 0, function* () { return yield resetdb(); }),
        purchase: (_, params) => __awaiter(void 0, void 0, void 0, function* () {
            console.log("trying to purchase with params: ", params);
            const { id, size, qty } = params;
            return yield purchaseShirt(id, size, qty);
        })
    }
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
exports.typeDefs = apollo_server_lambda_1.gql `
type Shirt {
  id:Int
  design:String
  small:Int
  medium:Int
  large:Int
}

type User {
	UUID: String
	Name: String
	Posts: [Post]
}

type Post {
	UUID: String
	Text: String
}

input UserInput {
	Name: String
	Posts: [PostInput]
}

input PostInput{
	Text: String
}



type Mutation {
	reset:String
  addshirt:String
  purchase(id:Int!,size:String!,qty:Int!):Shirt
}

type Query {
  hello: String
	mysql_getUser(uuid: String!): User
  getAll:[Shirt]
}

schema {
	query: Query
	mutation: Mutation
}
`;


/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const apolloServer = new apollo_server_lambda_1.ApolloServer({
    typeDefs: type_defs_1.typeDefs,
    resolvers: resolvers_1.resolvers
});
exports.graphqlHandler = apolloServer.createHandler({
    cors: {
        origin: '*',
        credentials: true,
    },
});

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiL2V4dGVybmFsIFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIiIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiL2V4dGVybmFsIFwic2VydmVybGVzcy1teXNxbFwiIiwid2VicGFjazovL3NlcnZlcmxlc3MtZGIvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vc2VydmVybGVzcy1kYi8uL3NyYy9hcG9sbG8tc2VydmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlxuLy9pbXBvcnQgeyB1dWlkdjQgfSBmcm9tICd1dWlkJztcbmNvbnN0IGRiY29uZmlnID0ge1xuICBob3N0OiBcIm5tZWd4MHowdGo0aG8xLmN4anB6bmRxNWg5My51cy13ZXN0LTEucmRzLmFtYXpvbmF3cy5jb21cIiwvL3Byb2Nlc3MuZW52Lk1ZU1FMX0hPU1QsXG4gIGRhdGFiYXNlOiBwcm9jZXNzLmVudi5EQl9OQU1FLFxuICB1c2VyOiBwcm9jZXNzLmVudi5VU0VSTkFNRSxcbiAgcGFzc3dvcmQ6IHByb2Nlc3MuZW52LlBBU1NXT1JEXG59XG5cblxuY29uc3QgY2xpZW50ID0gcmVxdWlyZSgnc2VydmVybGVzcy1teXNxbCcpKHtcbiAgY29uZmlnOmRiY29uZmlnXG59KVxuXG5cbmNvbnN0IHJlc2V0ZGIgPSBhc3luYyAoKSA9PiB7XG5jb25zb2xlLmxvZyhcIlJlc2V0dGluZyBEQiBjb25maWc6IFwiLGRiY29uZmlnKVxuXG4gIGF3YWl0IGNsaWVudC5xdWVyeShgXG4gIENSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIHNoaXJ0c1xuICAoXG4gICAgICBpZCBNRURJVU1JTlQgVU5TSUdORUQgbm90IG51bGwgQVVUT19JTkNSRU1FTlQsIFxuICAgICAgY3JlYXRlZCBUSU1FU1RBTVAgREVGQVVMVCBDVVJSRU5UX1RJTUVTVEFNUCwgXG4gICAgICBkZXNpZ24gdmFyY2hhcigxMDApIG5vdCBudWxsLFxuICAgICAgc21hbGwgSU5UIG5vdCBudWxsLFxuICAgICAgbWVkaXVtIElOVCBub3QgbnVsbCxcbiAgICAgIGxhcmdlIElOVCBub3QgbnVsbCxcbiAgICAgIFBSSU1BUlkgS0VZIChpZClcbiAgKTsgIFxuICBgKVxuICBjb25zb2xlLmxvZyhcIkNsZWFyaW5nIFRhYmxlLi4uLlwiKVxuICBhd2FpdCBjbGllbnQucXVlcnkoJ0RFTEVURSBGUk9NIHNoaXJ0cycpXG4gIGNvbnNvbGUubG9nKFwiQWRkaW5nIGluaXRhbCBzaGlydHNcIilcblxuICBhd2FpdCBjbGllbnQucXVlcnkoICdJTlNFUlQgSU5UTyBzaGlydHMgKGRlc2lnbixzbWFsbCxtZWRpdW0sbGFyZ2UpIFZBTFVFUyg/LD8sPyw/KScsIFtcImRlc2lnbjFcIiwxMCw1LDFdKTtcbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCAnSU5TRVJUIElOVE8gc2hpcnRzIChkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlKSBWQUxVRVMoPyw/LD8sPyknLCBbXCJkZXNpZ24yXCIsMywyLDVdKTtcbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCAnSU5TRVJUIElOVE8gc2hpcnRzIChkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlKSBWQUxVRVMoPyw/LD8sPyknLCBbXCJkZXNpZ24zXCIsMSwzLDJdKTtcbiAgXG4gIC8vIFJ1biBjbGVhbiB1cCBmdW5jdGlvblxuICBhd2FpdCBjbGllbnQuZW5kKClcbiAgcmV0dXJuIFwiU3VjY2Vzc1wiXG59XG5cblxuXG5cbmNvbnN0IGdldEFsbFNoaXJ0cyA9IGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJHZXR0dGluZyBhbGwgU2hpcnRzXCIpXG4gIGxldCBzaGlydHMgPSBbXVxuICBjb25zdCBzaGlydFJlc3VsdHMgPSBhd2FpdCBjbGllbnQucXVlcnkoYCBzZWxlY3QgKiBmcm9tIHNoaXJ0c2ApXG4gIGZvcihjb25zdCBzaGlydCBvZiBzaGlydFJlc3VsdHMpe1xuICAgIGNvbnN0IHtpZCxkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlfSA9IHNoaXJ0XG4gICAgY29uc29sZS5sb2coYFNoaXJ0IElEOiR7aWR9IC0gJHtkZXNpZ259IDogc21hbGwgUVRZOiAke3NtYWxsfSB8IG1lZGl1bSBRVFk6ICR7bWVkaXVtfSB8IGxhcmdlIFFUWTogJHtsYXJnZX0gYClcbiAgICBzaGlydHMucHVzaCh7aWQsZGVzaWduLHNtYWxsLG1lZGl1bSxsYXJnZX0pXG4gIH1cbiAgcmV0dXJuIHNoaXJ0c1xufVxuXG5jb25zdCBwdXJjaGFzZVNoaXJ0ID0gYXN5bmMgKGlkOk51bWJlcixzaXplOnN0cmluZyxxdHk6TnVtYmVyKSA9PiB7XG4gIGNvbnNvbGUubG9nKGBQdXJjaGFzaW5nIFNoaXJ0OiAgaWQ6ICR7aWR9LHNpemU6ICR7c2l6ZX0sIHB1cmNoYXNlIHF0eToke3F0eX1gKVxuICBcbiAgIGF3YWl0IGNsaWVudC5xdWVyeShgVVBEQVRFIHNoaXJ0cyBTRVQgJHtzaXplfSA9ICR7c2l6ZX0gLSAke3F0eX0gV0hFUkUgaWQgPSAke2lkfSBBTkQgJHtzaXplfS0ke3F0eX0+PSAwOyBgKVxuICBcbiAgIGNvbnN0IHNoaXJ0VXBkYXRlUmVzdWx0ID0gYXdhaXQgY2xpZW50LnF1ZXJ5KGBTRUxFQ1QgKiBmcm9tIHNoaXJ0cyBXSEVSRSBpZCA9ICR7aWR9OyBgKSAgXG4gIGNvbnNvbGUubG9nKFwic2hpcnRVcGRhdGVSZXN1bHQ6IFwiLHNoaXJ0VXBkYXRlUmVzdWx0WzBdKVxuXG4gIHJldHVybiBzaGlydFVwZGF0ZVJlc3VsdFswXVxufVxuXG5cblxuZXhwb3J0IGNvbnN0IHJlc29sdmVycyA9IHtcblxuXG4gIFF1ZXJ5OiB7XG4gICAgXG4gICAgaGVsbG86ICgpID0+ICdIZWxsbyB3b3JsZCEnLFxuICAgIGdldEFsbDogYXN5bmMgKCkgPT4geyByZXR1cm4gYXdhaXQgZ2V0QWxsU2hpcnRzKCkgfVxuICB9LFxuICBNdXRhdGlvbjoge1xuICAgIHJlc2V0OiAgYXN5bmMgKCkgPT4geyByZXR1cm4gYXdhaXQgcmVzZXRkYigpfSwgICBcbiAgICBwdXJjaGFzZTogYXN5bmMgKF86YW55LHBhcmFtczphbnkpPT57XG4gICAgXG4gICAgICBjb25zb2xlLmxvZyhcInRyeWluZyB0byBwdXJjaGFzZSB3aXRoIHBhcmFtczogXCIsIHBhcmFtcylcbiAgICAgIGNvbnN0IHtpZCxzaXplLHF0eX0gPSBwYXJhbXM7XG4gIFxuICAgICAgcmV0dXJuIGF3YWl0IHB1cmNoYXNlU2hpcnQoaWQsc2l6ZSxxdHkpXG4gICAgfSAgIFxuXG4gIH1cbn07XG4iLCJpbXBvcnQgeyBncWwgfSBmcm9tICdhcG9sbG8tc2VydmVyLWxhbWJkYSc7XG5cbmV4cG9ydCBjb25zdCB0eXBlRGVmcyA9IGdxbGBcbnR5cGUgU2hpcnQge1xuICBpZDpJbnRcbiAgZGVzaWduOlN0cmluZ1xuICBzbWFsbDpJbnRcbiAgbWVkaXVtOkludFxuICBsYXJnZTpJbnRcbn1cblxudHlwZSBVc2VyIHtcblx0VVVJRDogU3RyaW5nXG5cdE5hbWU6IFN0cmluZ1xuXHRQb3N0czogW1Bvc3RdXG59XG5cbnR5cGUgUG9zdCB7XG5cdFVVSUQ6IFN0cmluZ1xuXHRUZXh0OiBTdHJpbmdcbn1cblxuaW5wdXQgVXNlcklucHV0IHtcblx0TmFtZTogU3RyaW5nXG5cdFBvc3RzOiBbUG9zdElucHV0XVxufVxuXG5pbnB1dCBQb3N0SW5wdXR7XG5cdFRleHQ6IFN0cmluZ1xufVxuXG5cblxudHlwZSBNdXRhdGlvbiB7XG5cdHJlc2V0OlN0cmluZ1xuICBhZGRzaGlydDpTdHJpbmdcbiAgcHVyY2hhc2UoaWQ6SW50ISxzaXplOlN0cmluZyEscXR5OkludCEpOlNoaXJ0XG59XG5cbnR5cGUgUXVlcnkge1xuICBoZWxsbzogU3RyaW5nXG5cdG15c3FsX2dldFVzZXIodXVpZDogU3RyaW5nISk6IFVzZXJcbiAgZ2V0QWxsOltTaGlydF1cbn1cblxuc2NoZW1hIHtcblx0cXVlcnk6IFF1ZXJ5XG5cdG11dGF0aW9uOiBNdXRhdGlvblxufVxuYDtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzZXJ2ZXJsZXNzLW15c3FsXCIpOzsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHRpZihfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdKSB7XG5cdFx0cmV0dXJuIF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0uZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsImltcG9ydCB7IEFwb2xsb1NlcnZlciB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItbGFtYmRhJztcbmltcG9ydCB7IENvbnRleHQsIEFQSUdhdGV3YXlFdmVudCwgQVBJR2F0ZXdheVByb3h5UmVzdWx0VjIgfSBmcm9tIFwiYXdzLWxhbWJkYVwiO1xuaW1wb3J0IHsgcmVzb2x2ZXJzIH0gZnJvbSAnLi9yZXNvbHZlcnMnO1xuaW1wb3J0IHsgdHlwZURlZnMgfSBmcm9tICcuL3R5cGUtZGVmcyc7XG5cbi8vY29uc3QgYXBvbGxvU2VydmVyID0gbmV3IEFwb2xsb1NlcnZlcih7IHJlc29sdmVycywgdHlwZURlZnMgfSk7XG5cbmNvbnN0IGFwb2xsb1NlcnZlciA9IG5ldyBBcG9sbG9TZXJ2ZXIoe1xuXG5cdHR5cGVEZWZzLFxuXHRyZXNvbHZlcnMgfSk7XG5cblxuZXhwb3J0IGNvbnN0IGdyYXBocWxIYW5kbGVyID0gYXBvbGxvU2VydmVyLmNyZWF0ZUhhbmRsZXIoe1xuICAgIGNvcnM6IHtcbiAgICAgIG9yaWdpbjogJyonLFxuICAgICAgY3JlZGVudGlhbHM6IHRydWUsXG4gICAgfSxcbiAgfSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7O0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFJQTtBQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBOzs7Ozs7OztBQzVGQTtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStDQTtBQUNBO0FBQ0E7QTs7Ozs7QUNuREE7QUFDQTtBOzs7OztBQ0RBO0FBQ0E7QTs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3RCQTtBQUVBO0FBQ0E7QUFJQTtBQUVBO0FBQ0E7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QSIsInNvdXJjZVJvb3QiOiIifQ==