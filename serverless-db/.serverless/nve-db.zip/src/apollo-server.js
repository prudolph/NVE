/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 981:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
const dbconfig = {
    host: "nmegx0z0tj4ho1.cxjpzndq5h93.us-west-1.rds.amazonaws.com",
    database: process.env.DB_NAME,
    user: process.env.USERNAME,
    password: process.env.PASSWORD
};
const client = __webpack_require__(202)({
    config: dbconfig
});
const resetdb = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Resetting DB config: ", dbconfig);
    yield client.query(`
  CREATE TABLE IF NOT EXISTS shirts
  (
      id MEDIUMINT UNSIGNED not null AUTO_INCREMENT, 
      created TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
      design varchar(100) not null,
      small INT not null,
      medium INT not null,
      large INT not null,
      PRIMARY KEY (id)
  );  
  `);
    console.log("Clearing Table....");
    yield client.query('DELETE FROM shirts');
    console.log("Adding inital shirts");
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design1", 10, 5, 1]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design2", 3, 2, 5]);
    yield client.query('INSERT INTO shirts (design,small,medium,large) VALUES(?,?,?,?)', ["design3", 1, 3, 2]);
    yield client.end();
    return "Success";
});
const getAllShirts = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Gettting all Shirts");
    let shirts = [];
    const shirtResults = yield client.query(` select * from shirts`);
    for (const shirt of shirtResults) {
        const { id, design, small, medium, large } = shirt;
        console.log(`Shirt ID:${id} - ${design} : small QTY: ${small} | medium QTY: ${medium} | large QTY: ${large} `);
        shirts.push({ id, design, small, medium, large });
    }
    console.log("SHIRTS REturned: , ", shirts);
    return shirts;
});
exports.resolvers = {
    Query: {
        hello: () => 'Hello world!',
        getAll: () => __awaiter(void 0, void 0, void 0, function* () { return yield getAllShirts(); })
    },
    Mutation: {
        reset: () => __awaiter(void 0, void 0, void 0, function* () { return yield resetdb(); }),
    }
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
exports.typeDefs = apollo_server_lambda_1.gql `
type Shirt {
  id:Int
  design:String
  small:Int
  medium:Int
  large:Int
}

type User {
	UUID: String
	Name: String
	Posts: [Post]
}

type Post {
	UUID: String
	Text: String
}

input UserInput {
	Name: String
	Posts: [PostInput]
}

input PostInput{
	Text: String
}



type Mutation {
	reset:String
  addshirt:String
}

type Query {
  hello: String
	mysql_getUser(uuid: String!): User
  getAll:[Shirt]
}

schema {
	query: Query
	mutation: Mutation
}
`;


/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
const apolloServer = new apollo_server_lambda_1.ApolloServer({ resolvers: resolvers_1.resolvers, typeDefs: type_defs_1.typeDefs });
exports.graphqlHandler = apolloServer.createHandler();

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2Fwb2xsby1zZXJ2ZXIuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3Jlc29sdmVycy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiL2V4dGVybmFsIFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIiIsIndlYnBhY2s6Ly9zZXJ2ZXJsZXNzLWRiL2V4dGVybmFsIFwic2VydmVybGVzcy1teXNxbFwiIiwid2VicGFjazovL3NlcnZlcmxlc3MtZGIvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vc2VydmVybGVzcy1kYi8uL3NyYy9hcG9sbG8tc2VydmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlxuLy9pbXBvcnQgeyB1dWlkdjQgfSBmcm9tICd1dWlkJztcbmNvbnN0IGRiY29uZmlnID0ge1xuICBob3N0OiBcIm5tZWd4MHowdGo0aG8xLmN4anB6bmRxNWg5My51cy13ZXN0LTEucmRzLmFtYXpvbmF3cy5jb21cIiwvL3Byb2Nlc3MuZW52Lk1ZU1FMX0hPU1QsXG4gIGRhdGFiYXNlOiBwcm9jZXNzLmVudi5EQl9OQU1FLFxuICB1c2VyOiBwcm9jZXNzLmVudi5VU0VSTkFNRSxcbiAgcGFzc3dvcmQ6IHByb2Nlc3MuZW52LlBBU1NXT1JEXG59XG5cblxuY29uc3QgY2xpZW50ID0gcmVxdWlyZSgnc2VydmVybGVzcy1teXNxbCcpKHtcbiAgY29uZmlnOmRiY29uZmlnXG59KVxuXG5cbmNvbnN0IHJlc2V0ZGIgPSBhc3luYyAoKSA9PiB7XG5jb25zb2xlLmxvZyhcIlJlc2V0dGluZyBEQiBjb25maWc6IFwiLGRiY29uZmlnKVxuXG4gIGF3YWl0IGNsaWVudC5xdWVyeShgXG4gIENSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIHNoaXJ0c1xuICAoXG4gICAgICBpZCBNRURJVU1JTlQgVU5TSUdORUQgbm90IG51bGwgQVVUT19JTkNSRU1FTlQsIFxuICAgICAgY3JlYXRlZCBUSU1FU1RBTVAgREVGQVVMVCBDVVJSRU5UX1RJTUVTVEFNUCwgXG4gICAgICBkZXNpZ24gdmFyY2hhcigxMDApIG5vdCBudWxsLFxuICAgICAgc21hbGwgSU5UIG5vdCBudWxsLFxuICAgICAgbWVkaXVtIElOVCBub3QgbnVsbCxcbiAgICAgIGxhcmdlIElOVCBub3QgbnVsbCxcbiAgICAgIFBSSU1BUlkgS0VZIChpZClcbiAgKTsgIFxuICBgKVxuICBjb25zb2xlLmxvZyhcIkNsZWFyaW5nIFRhYmxlLi4uLlwiKVxuICBhd2FpdCBjbGllbnQucXVlcnkoJ0RFTEVURSBGUk9NIHNoaXJ0cycpXG4gIGNvbnNvbGUubG9nKFwiQWRkaW5nIGluaXRhbCBzaGlydHNcIilcblxuICBhd2FpdCBjbGllbnQucXVlcnkoICdJTlNFUlQgSU5UTyBzaGlydHMgKGRlc2lnbixzbWFsbCxtZWRpdW0sbGFyZ2UpIFZBTFVFUyg/LD8sPyw/KScsIFtcImRlc2lnbjFcIiwxMCw1LDFdKTtcbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCAnSU5TRVJUIElOVE8gc2hpcnRzIChkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlKSBWQUxVRVMoPyw/LD8sPyknLCBbXCJkZXNpZ24yXCIsMywyLDVdKTtcbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KCAnSU5TRVJUIElOVE8gc2hpcnRzIChkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlKSBWQUxVRVMoPyw/LD8sPyknLCBbXCJkZXNpZ24zXCIsMSwzLDJdKTtcbiAgXG4gIC8vIFJ1biBjbGVhbiB1cCBmdW5jdGlvblxuICBhd2FpdCBjbGllbnQuZW5kKClcbiAgcmV0dXJuIFwiU3VjY2Vzc1wiXG59XG5cblxuXG5cbmNvbnN0IGdldEFsbFNoaXJ0cyA9IGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJHZXR0dGluZyBhbGwgU2hpcnRzXCIpXG5cbiAgXG4gIGxldCBzaGlydHMgPSBbXVxuICBjb25zdCBzaGlydFJlc3VsdHMgPSBhd2FpdCBjbGllbnQucXVlcnkoYCBzZWxlY3QgKiBmcm9tIHNoaXJ0c2ApXG5cbiAgXG4gIGZvcihjb25zdCBzaGlydCBvZiBzaGlydFJlc3VsdHMpe1xuICAgIFxuICAgIGNvbnN0IHtpZCxkZXNpZ24sc21hbGwsbWVkaXVtLGxhcmdlfSA9IHNoaXJ0XG4gICAgY29uc29sZS5sb2coYFNoaXJ0IElEOiR7aWR9IC0gJHtkZXNpZ259IDogc21hbGwgUVRZOiAke3NtYWxsfSB8IG1lZGl1bSBRVFk6ICR7bWVkaXVtfSB8IGxhcmdlIFFUWTogJHtsYXJnZX0gYClcbiAgICBzaGlydHMucHVzaCh7aWQsZGVzaWduLHNtYWxsLG1lZGl1bSxsYXJnZX0pXG4gIH1cbiAgXG5jb25zb2xlLmxvZyhcIlNISVJUUyBSRXR1cm5lZDogLCBcIiwgc2hpcnRzKVxuICByZXR1cm4gc2hpcnRzXG4gIH1cblxuXG5cbmV4cG9ydCBjb25zdCByZXNvbHZlcnMgPSB7XG5cblxuICBRdWVyeToge1xuICAgIFxuICAgIGhlbGxvOiAoKSA9PiAnSGVsbG8gd29ybGQhJyxcbiAgICBnZXRBbGw6IGFzeW5jICgpID0+IHsgcmV0dXJuIGF3YWl0IGdldEFsbFNoaXJ0cygpIH1cbiAgfSxcbiAgTXV0YXRpb246IHtcbiAgICByZXNldDogIGFzeW5jICgpID0+IHsgcmV0dXJuIGF3YWl0IHJlc2V0ZGIoKX0sICAgICAgXG5cbiAgfVxufTtcbiIsImltcG9ydCB7IGdxbCB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItbGFtYmRhJztcblxuZXhwb3J0IGNvbnN0IHR5cGVEZWZzID0gZ3FsYFxudHlwZSBTaGlydCB7XG4gIGlkOkludFxuICBkZXNpZ246U3RyaW5nXG4gIHNtYWxsOkludFxuICBtZWRpdW06SW50XG4gIGxhcmdlOkludFxufVxuXG50eXBlIFVzZXIge1xuXHRVVUlEOiBTdHJpbmdcblx0TmFtZTogU3RyaW5nXG5cdFBvc3RzOiBbUG9zdF1cbn1cblxudHlwZSBQb3N0IHtcblx0VVVJRDogU3RyaW5nXG5cdFRleHQ6IFN0cmluZ1xufVxuXG5pbnB1dCBVc2VySW5wdXQge1xuXHROYW1lOiBTdHJpbmdcblx0UG9zdHM6IFtQb3N0SW5wdXRdXG59XG5cbmlucHV0IFBvc3RJbnB1dHtcblx0VGV4dDogU3RyaW5nXG59XG5cblxuXG50eXBlIE11dGF0aW9uIHtcblx0cmVzZXQ6U3RyaW5nXG4gIGFkZHNoaXJ0OlN0cmluZ1xufVxuXG50eXBlIFF1ZXJ5IHtcbiAgaGVsbG86IFN0cmluZ1xuXHRteXNxbF9nZXRVc2VyKHV1aWQ6IFN0cmluZyEpOiBVc2VyXG4gIGdldEFsbDpbU2hpcnRdXG59XG5cbnNjaGVtYSB7XG5cdHF1ZXJ5OiBRdWVyeVxuXHRtdXRhdGlvbjogTXV0YXRpb25cbn1cbmA7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic2VydmVybGVzcy1teXNxbFwiKTs7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0aWYoX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSkge1xuXHRcdHJldHVybiBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCJpbXBvcnQgeyBBcG9sbG9TZXJ2ZXIgfSBmcm9tICdhcG9sbG8tc2VydmVyLWxhbWJkYSc7XG5pbXBvcnQgeyBDb250ZXh0LCBBUElHYXRld2F5RXZlbnQsIEFQSUdhdGV3YXlQcm94eVJlc3VsdFYyIH0gZnJvbSBcImF3cy1sYW1iZGFcIjtcbmltcG9ydCB7IHJlc29sdmVycyB9IGZyb20gJy4vcmVzb2x2ZXJzJztcbmltcG9ydCB7IHR5cGVEZWZzIH0gZnJvbSAnLi90eXBlLWRlZnMnO1xuXG5jb25zdCBhcG9sbG9TZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHsgcmVzb2x2ZXJzLCB0eXBlRGVmcyB9KTtcblxuZXhwb3J0IGNvbnN0IGdyYXBocWxIYW5kbGVyID0gYXBvbGxvU2VydmVyLmNyZWF0ZUhhbmRsZXIoKTtcblxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUVBOzs7Ozs7Ozs7OztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBS0E7QUFDQTtBQUdBO0FBQ0E7QUFHQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSUE7QUFHQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBOzs7Ozs7OztBQ2pGQTtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBOENBO0FBQ0E7QUFDQTtBOzs7OztBQ2xEQTtBQUNBO0E7Ozs7O0FDREE7QUFDQTtBOzs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdEJBO0FBRUE7QUFDQTtBQUVBO0FBRUE7Ozs7Ozs7O0EiLCJzb3VyY2VSb290IjoiIn0=